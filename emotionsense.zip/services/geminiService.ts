
import { GoogleGenAI } from "@google/genai";
import { type EmotionResult, Emotion } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not found.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const validEmotions = Object.values(Emotion);

export const detectEmotion = async (text: string): Promise<EmotionResult> => {
  const prompt = `Analyze the predominant emotion of the following text. Respond with only a single, raw JSON object in the format {"emotion": "EMOTION_NAME", "emoji": "EMOJI"}. The EMOTION_NAME must be one of the following exact values: ${validEmotions.join(', ')}.

Text: "${text}"`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.3,
      },
    });

    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    
    const parsedData = JSON.parse(jsonStr) as EmotionResult;

    // Validate the parsed data
    if (!parsedData.emotion || !validEmotions.includes(parsedData.emotion)) {
      throw new Error(`API returned an invalid emotion: ${parsedData.emotion}`);
    }
    if (!parsedData.emoji || typeof parsedData.emoji !== 'string') {
        throw new Error('API response missing or has invalid emoji.');
    }

    return parsedData;

  } catch (error) {
    console.error("Error detecting emotion:", error);
    if (error instanceof Error && error.message.includes('json')) {
      throw new Error("Could not understand the model's response. Please try a different text.");
    }
    throw new Error("Failed to communicate with the emotion detection service. Please try again later.");
  }
};
