
export enum Emotion {
  Happy = 'Happy',
  Sad = 'Sad',
  Angry = 'Angry',
  Fear = 'Fear',
  Love = 'Love',
  Surprise = 'Surprise',
  Neutral = 'Neutral',
}

export interface EmotionResult {
  emotion: Emotion;
  emoji: string;
}
