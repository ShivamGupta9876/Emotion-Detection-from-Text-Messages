
import React, { useState, useCallback } from 'react';
import { detectEmotion } from './services/geminiService';
import { type EmotionResult as EmotionResultType } from './types';
import Loader from './components/Loader';
import EmotionResult from './components/EmotionResult';
import InfoSection from './components/InfoSection';

const App: React.FC = () => {
  const [text, setText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<EmotionResultType | null>(null);

  const handleDetection = useCallback(async () => {
    if (!text.trim()) {
      setError('Please enter some text to analyze.');
      return;
    }
    
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const detectedEmotion = await detectEmotion(text);
      setResult(detectedEmotion);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [text]);

  const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleDetection();
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 text-slate-800 transition-all duration-300">
      <main className="w-full max-w-2xl bg-white rounded-2xl shadow-xl p-6 sm:p-10 transition-all duration-300">
        <div className="text-center">
          <h1 className="text-3xl sm:text-4xl font-bold text-sky-800">
            EmotionSense
          </h1>
          <p className="mt-2 text-md sm:text-lg text-slate-500">
            Understand the emotions behind your words instantly.
          </p>
        </div>

        <div className="mt-8 space-y-6">
          <div className="relative">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type or paste your message here..."
              className="w-full h-32 p-4 text-base bg-slate-100 border-2 border-transparent rounded-xl focus:ring-2 focus:ring-sky-400 focus:outline-none focus:border-sky-400 resize-none transition-all duration-300"
              disabled={isLoading}
            />
          </div>
          <button
            onClick={handleDetection}
            disabled={isLoading}
            className="w-full py-3 px-4 bg-sky-500 text-white font-semibold rounded-xl hover:bg-sky-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500 disabled:bg-slate-300 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 active:scale-100 flex items-center justify-center shadow-md"
          >
            {isLoading ? <Loader /> : 'Detect Emotion'}
          </button>
        </div>

        <div className="mt-8 min-h-[120px] flex items-center justify-center">
          {error && <p className="text-red-500 text-center">{error}</p>}
          {result && !isLoading && <EmotionResult result={result} />}
        </div>
      </main>
      <InfoSection />
    </div>
  );
};

export default App;
