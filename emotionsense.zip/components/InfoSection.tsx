
import React from 'react';

const InfoSection: React.FC = () => {
  return (
    <footer className="w-full max-w-2xl mt-6 p-6 text-center text-slate-600">
      <div className="bg-white/70 backdrop-blur-sm p-6 rounded-2xl shadow-md">
        <h3 className="text-lg font-semibold text-sky-800 mb-2">How It Works</h3>
        <p className="text-sm sm:text-base">
          Our EmotionSense tool uses a powerful AI model from Google (Gemini) trained on vast amounts of text. When you enter a message, the AI analyzes the words, context, and nuances to predict the most likely underlying emotion. This provides a quick glimpse into the emotional tone of the text.
        </p>
      </div>
    </footer>
  );
};

export default InfoSection;
