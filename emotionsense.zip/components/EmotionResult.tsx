
import React, { useState, useEffect } from 'react';
import { type EmotionResult as EmotionResultType } from '../types';

interface EmotionResultProps {
  result: EmotionResultType;
}

const EmotionResult: React.FC<EmotionResultProps> = ({ result }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Trigger the animation shortly after the component mounts
    const timer = setTimeout(() => setVisible(true), 10);
    return () => clearTimeout(timer);
  }, [result]);

  return (
    <div
      className={`text-center transition-all duration-500 ease-out ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
    >
      <div className="text-6xl sm:text-7xl mb-3">{result.emoji}</div>
      <p className="text-xl sm:text-2xl font-semibold text-slate-700">
        Predicted Emotion: <span className="text-pink-500">{result.emotion}</span>
      </p>
    </div>
  );
};

export default EmotionResult;
